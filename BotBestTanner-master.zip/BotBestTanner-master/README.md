## BTR Tanner
The fastest F2P money making with no requirements!

Get that bond ASAP!
Tan Cowhide into Leather for maximum profit in Al Kharid.

![BTR Tanner running flawlessly](https://i.imgur.com/tqBVHHa.png)

#### **WHY?**

* Tan 2000 per hour
* Profit tracker
* Best paint
* Stops when done

#### **HOW?**
1. Have Cowhide, near Al Kharid
1. Start & relax...
1. **Profit!**

#### **BEST PAINT**
![How to read the best paint](https://i.imgur.com/Ikh9PXC.png)

#### Want to get tanning? [Get it on the repository](https://scripts.rspeer.org/#/Search/Best%20Tanner)

---
###### Source code: https://github.com/troy-lamerton/BotBestTanner


